import React from 'react'

export default function mutual() {
    return (
        <div style={{textAlign:"center"}}>
           <h1>Mutual Funds</h1> 
        </div>
    )
}
