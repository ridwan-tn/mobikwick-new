import React from 'react'

export default function payemt() {
    return (
        <div style={{textAlign:"center"}}>
           <h1>Payemnt Gateway</h1> 
        </div>
    )
}
