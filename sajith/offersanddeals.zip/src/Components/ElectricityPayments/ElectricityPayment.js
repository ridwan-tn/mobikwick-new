import React from 'react'

import PaymentForm from './PaymentForm'
function ElectricityPayment() {
  return (
    <div className="container-fluid">
      <div className="row">

      </div>
      <div className="row row-container">
            <PaymentForm/>
        
      </div>
    </div>
  );
}

export default ElectricityPayment
