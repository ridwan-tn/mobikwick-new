import React from 'react'
import PageHeaderRoutes from '../../Routes/PageHeaderRoutes'
export default function SingleSection() {
    return (
        <>
   
            <PageHeaderRoutes/>
        </>
    )
}
