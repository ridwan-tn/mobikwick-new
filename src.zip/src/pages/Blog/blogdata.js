
const blogdata = [
    {
      id: 1,
      image:'https://blog.mobikwik.com/wp-content/uploads/2021/05/blog-creative-1.png',
      info:"Team MobiKwik | M a y 21, 2021 |  ",
      info1:'Information',
      title: 'MobiKwik – Helping you to battle the pandemic!',
      like:3,
      description:"Your safety is our priority, therefore we aim to help everyone survive this battle together with our support. We want to assure you that MobiKwik is making every effort in"
       },
       {id: 2,
       image:'https://blog.mobikwik.com/wp-content/uploads/2021/04/LIC-Cover.jpg',
       info:"Team MobiKwik |A p r i l 13, 2021 |  ",
       info1:'Bill Payment',
       title: 'LIC Premium Payment on MobiKwik!',
       like:5,
       description:"Your LIC premium payments are just a click away! We are glad to announce that you can now make hassle-free LIC premium payments via MobiKwik in just a few steps."
        },
        {id: 3,
            image:'https://blog.mobikwik.com/wp-content/uploads/2021/01/1200x628-1.png',
            info:"Upasana Taku January 28, 2021  ",
            info1:'Reports',
            title: 'MobiKwik partners with Home Credit India!',
            like:33,
            description:"Extremely excited to announce that we’ve partnered with Home Credit India, a local arm of the international consumer finance provider Home Credit Group with operations spanning in 9 countries across"
             },
             {id: 4,
                image:'https://blog.mobikwik.com/wp-content/uploads/2020/12/Siddhath-Dhamija_Blog.jpg',
                info:"Bipin Preet Singh December 17, 2020",
                info1:'Payment Gateway ',
                title: 'MobiKwik appoints Siddharth Dhamija as CEO of Zaakpay',
                like:22,
                description:"I am elated to announce that Siddharth Dhamija has been appointed as CEO of Zaakpay. Zaakpay is the payment gateway arm of our company, which clocked 194 crores revenue (up"
                 },
            {id: 5,
            image:'https://blog.mobikwik.com/wp-content/uploads/2020/11/1200x628_v2-2.png',
            info:"Upasana Taku November 10, 2020",
            info1:'Reports',
            title: 'MobiKwik launches its first card – The Blue Card!',
            like:37,
            description:"Today we are unveiling the future of Credit in India. Super excited to announce the launch of the ‘MobiKwik Blue American Express Card’, our first card for millions of ambitious"
            },
            {
            id: 6,
            image:'https://blog.mobikwik.com/wp-content/uploads/2020/09/Blog-1.png',
            info:"Bipin Preet Singh September 15, 2020",
            info1:'Reports ',
            title: 'MobiKwik starts IPO prep: Elevates SVP Chandan Joshi to Co-Founder',
            like:23,
            description:""
             },
             {
                id: 7,
                image:'https://blog.mobikwik.com/wp-content/uploads/2020/07/1200x628-4-1.png',
                info:"Upasana Taku July 27, 2020 ",
                info1:'Money Transfer',
                title: 'Launching Personal UPI Payment Link mpay.me',
                like:36,
                description:"At MobiKwik, payments are our first love! But there’s another contender for our love, UPI – the payments system developed by the National Payments Corporation of India. UPI has truly"
                 },
            {
            id: 8,
            image:'https://blog.mobikwik.com/wp-content/uploads/2020/07/Annual-Report_Cover-Page_1200x628.png',
            info:"Upasana Taku July 15, 2020",
            info1:'Reports ',
            title: 'MobiKwik Annual Report FY2020: The Indian Dream',
            like:14,
            description:"Prologue Once upon a time, a young woman visited India for vacation. Whilst enjoying her trip, one day she got very frustrated spending hours booking a train ticket. She got"
            },
            {
            id: 9,
            image:'https://blog.mobikwik.com/wp-content/uploads/2020/07/1200x628-9.png',
            info:"Team MobiKwik July 7, 2020",
            info1:'Information',
            title: 'Instant money access using smartphone!',
            like:24,
            description:"We all know, we should be well prepared for ‘a rainy day’ but what do we do when rain arrives before we are ready?  The current Covid situation is a"
            },
            {
            id: 10,
            image:'https://blog.mobikwik.com/wp-content/uploads/2020/06/1200x628-3.png',
            info:"Team MobiKwik June 25, 2020 ",
            info1:'Information',
            title: 'Ace your virtual interview in COVID times!',
            like:14,
            description:"In this tough time amidst pandemic, many companies have decided to freeze hiring. The job opportunities are few and so it is critical to leave a positive impression in the"
            },

      
  ]
  export default blogdata