
const datas = [
    {
      id: 1,
      title: 'Bipin Preet Singh',
      image:'https://www.mobikwik.com/assets/images/team/Bipin-Preet-Singh.png',
      info:'CoFounder & CEO',
      icon1:"https://www.mobikwik.com/assets/images/linkedin.svg",
      icon2:"https://static01.nyt.com/images/2014/08/10/magazine/10wmt/10wmt-articleLarge-v4.jpg?quality=75&auto=webp&disable=upscale"
       },

      {
        id: 2,
        title: 'Upasana Taku',
        image:'https://www.mobikwik.com/assets/images/team/Upasana-Taku.png',
        info:'CoFounder & COO',
        icon1:"https://www.mobikwik.com/assets/images/linkedin.svg",
        icon2:"https://static01.nyt.com/images/2014/08/10/magazine/10wmt/10wmt-articleLarge-v4.jpg?quality=75&auto=webp&disable=upscale"
    },
        {
            id: 3,
            title: 'Chandan Joshi',
            image:'https://www.mobikwik.com/assets/images/team/Chandan.png',
            info:'CoFounder & CEO Payments Business',
            icon1:"https://www.mobikwik.com/assets/images/linkedin.svg",
            icon2:"https://static01.nyt.com/images/2014/08/10/magazine/10wmt/10wmt-articleLarge-v4.jpg?quality=75&auto=webp&disable=upscale"
          
           },
        {
            id: 4,
            title: 'Siddharth Dhamija',
            image:'https://www.mobikwik.com/assets/images/team/Siddharth.png',
            info:'CEO, Zaakpay Business' ,
            icon1:"https://www.mobikwik.com/assets/images/linkedin.svg",
            icon2:"https://static01.nyt.com/images/2014/08/10/magazine/10wmt/10wmt-articleLarge-v4.jpg?quality=75&auto=webp&disable=upscale"
           
           },
        {
            id: 5,
            title: 'Dheeraj Aneja',
            image:'https://www.mobikwik.com/assets/images/team/Dheeraj.png',
            info:'SVP Credit & Cards',
            icon1:"https://www.mobikwik.com/assets/images/linkedin.svg"
           },
        {
            id: 6,
            title: 'Gaurav Malhotra',
            image:'https://www.mobikwik.com/assets/images/team/Gaurav.png',
            info:'VP Investor Relation',
            icon1:"https://www.mobikwik.com/assets/images/linkedin.svg "   },
        {
            id: 7,
            title: 'Chirag Jain',
            image:'https://www.mobikwik.com/assets/images/team/Chirag.png',
            info:'VP Technology' ,
            icon1:"https://www.mobikwik.com/assets/images/linkedin.svg"
           },
        {
            id: 8,
            title: 'Preety Pandey',
            image:'https://www.mobikwik.com/assets/images/team/Preety.png',
            info:'VP Corporate Finance',
            icon1:"https://www.mobikwik.com/assets/images/linkedin.svg"
           },
        {
            id: 9,
            title: 'Saurabh Jain',
            image:'https://www.mobikwik.com/assets/images/team/saurabh.png',
            info:'VP Financial Controllership',
            icon1:"https://www.mobikwik.com/assets/images/linkedin.svg"
            },
        {
            id: 10,
            title: 'Gaurav Kumar',
            image:'https://www.mobikwik.com/assets/images/team/Gaurav-K.png',
            info:'AVP Data',
            icon1:"https://www.mobikwik.com/assets/images/linkedin.svg"
            },
        {
            id: 11,
            title: 'Rahul Das',
            image:'https://www.mobikwik.com/assets/images/team/Rahul-das.png',
            info:'AVP Product Design',
            icon1:"https://www.mobikwik.com/assets/images/linkedin.svg"
            },
        {
            id: 12,
            title: 'Reshma Chothani',
            image:'https://www.mobikwik.com/assets/images/team/Reshma.png',
            info:'Head, Banking Alliances',
            icon1:"https://www.mobikwik.com/assets/images/linkedin.svg"
           }
   
  ]
  export default datas