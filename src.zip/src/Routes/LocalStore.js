import React from 'react'
import { BrowserRouter  ,  Switch, Route} from 'react-router-dom'
import About from '../pages/About/about'
import Apps from '../pages/appspage/apps'
import Blog from '../pages/Blog/Blog'
import Career from '../pages/career/career'
import Contact from '../pages/contact/contact'
import Sitemap from '../pages/sitemap/sitemap'

export default function LocalStore() {
    return (
        <div>
     
       
        
      </div>
    )
}
